package com.example.demo;

import com.example.demo.WebCrawling.IsOnTheHours;
import com.example.demo.repsitory.updateDB;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Openmk1Application {

	public static void main(String[] args) {
		SpringApplication.run(Openmk1Application.class, args);
//정각이면 데이터 업데이트후 웹페이지 업데이트
		if(IsOnTheHours.isonthehours()){
			updateDB.processRecordsFromMaxBoxId(updateDB.getMaxBoxId());
		}

	}

}
