package com.example.demo.WebCrawling;

import com.example.demo.model.Product;
import com.example.demo.model.Shoes;
import io.github.bonigarcia.wdm.WebDriverManager;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;               ////////////셀레니움
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

//////////////////////////////////
////////////////////////////
import java.time.LocalTime;// 현재 시간 클래스;


@Slf4j
public class WebCrawler {

    public static Product Crawling(String address) {

        Product product= new Product();
        log.info("crawling start");

///시간 라이브러리로 시간마다 업데이트
        if(true/*isOnTheHour*/){ // 분==0, 초==0 -> 정시를 의미. 정시마다 업데이트
            WebDriverManager.chromedriver().setup();

            ChromeOptions options = new ChromeOptions();
            options.addArguments("--lang=ko_KR");
            WebDriver driver = new ChromeDriver(options);

            try {
                log.info("start web: {}", address);
//                driver.get("https://kream.co.kr/products/21935?size=280");
                  driver.get(address);
                WebElement imageElement = driver.findElement(By.cssSelector("img.image.full_width"));
                String imgsrc = imageElement.getAttribute("src");

                WebElement imageElement1 = driver.findElement(By.cssSelector("p.title"));
                String name = imageElement1.getText();

                WebElement imageElement2 = driver.findElement(By.cssSelector("span.title-txt"));
                String size = imageElement2.getText();
              /*  int num1 = Integer.parseInt(size);*/

                WebElement imageElement3 = driver.findElement(By.cssSelector("em.num"));
                String price = imageElement3.getText();
                price = price.replace(",", "");
                int num2 = Integer.parseInt(price);

                product.SetProduct(imgsrc,name,size,num2);
                log.info("img: {}, name: {}, size: {}, price: {}", product.getImgsrc(), product.getName(), product.getSize(), product.getPrice());

            } catch (Exception e) {
                log.error("An error occurred: ", e);
            } finally {
                driver.quit();
            }
        }

     System.out.println("success\n");
        return product;


        /////////////////////////////

    }
}