package com.example.demo.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginDTO {
    private String ID;
    private String password;
    private String name;
    private String Gender;


}