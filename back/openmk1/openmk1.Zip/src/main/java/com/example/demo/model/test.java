package com.example.demo.model;

public class test {
    public static void main(String[] args) {
      /*  String a="zzzzzzzzzz";
        String b="1111111";
        int c=0;
        int d=0;
        Product dsa= new Product(a,b,c,d);
        System.out.println(dsa.name);*/
        String url = "https://kream.co.kr/products/205409";
        int length = url.length();
        System.out.println("URL 길이: " + length);
    }
}
